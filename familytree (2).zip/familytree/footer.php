
	<div class="pt-footer">
		<div class="pt-container">
				Copyright © <?php echo date('Y') ?> <a href="<?=path?>"><?=site_title?></a>. All Rights Reserved.<br><br>
		</div>
	</div>
</div>


<!-- jQuery Library -->
<script src="<?=path?>/assets/js/jquery.min.js"></script>
<script src="<?=path?>/assets/js/popper.min.js"></script>
<script src="<?=path?>/assets/js/bootstrap.min.js"></script>
<script src="<?=path?>/assets/js/jquery.livequery.js"></script>
<script src="<?=path?>/assets/js/jquery-confirm.min.js"></script>
<script src="<?=path?>/assets/js/fileinput.min.js"></script>
<script src="<?=path?>/assets/js/lightbox.js"></script>
<script src="<?=path?>/assets/js/datepicker.min.js"></script>
<script src="<?=path?>/assets/js/datepicker.en.js"></script>
<script src="<?=path?>/assets/js/Chart.min.js"></script>
<script src="<?=path?>/assets/js/jquery.uploader.js"></script>
<script src="<?=path?>/assets/js/jspdf.min.js"></script>
<script src="<?=path?>/assets/js/html2canvas.js"></script>
<script src="<?=path?>/assets/js/panzoom.min.js"></script>
<script src="<?=path?>/assets/js/jquery.amsify.suggestags.js"></script>

<script> var path = '<?=path?>',  nophoto = '<?=nophoto?>', lang = <?=json_encode($lang)?>;</script>

<!-- Main JS -->
<script src="<?=path?>/assets/js/custom.js"></script>

</body>
</html>
