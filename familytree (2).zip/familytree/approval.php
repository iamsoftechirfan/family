<!DOCTYPE html>
<html lang="en">
<head>
  <title>Approval</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>  

</head>
<body>
	<style>
		.alert.alert-success {
			padding: 15px;
			margin-top: 10px;
			width: 80%;
			text-align: center;
			margin-left: 10%;
		}
	</style> 
<?php
 
include __DIR__ . '/configs/config.php';
// $sql_irf = mysql_query("SELECT SUM(pointtillthattime) as total FROM range_of_approval_log");
// print_r($sql_irf);
// $row_irf = mysql_fetch_array($sql_irf);
// $sum = $row_irf['total'];
// echo $sum;
date_default_timezone_set("Asia/Kolkata");
$my_token = 0;
$token= $_GET['token'];
$mid = base64_decode($_GET['mid']);
$member = db_select([
	'table'  => 'members',
	'where'  => 'id = "' . $mid . '" '
]);
$rs = $member->fetch_assoc();

$get_token = db_get("range_of_approval_log", "token", $token, 'token', 'ORDER BY id DESC LIMIT 1');
if(($get_token)){
	$my_token = 1;
}


if($_SERVER['REQUEST_METHOD'] == 'POST'){
	
	$res=db_update('members', ['status' => 1], $mid);
	
	$author = $rs['author'];
	$get_previous_totalpoints=db_get('users', 'total_points', $author);
	$count_merbers = db_select([
		'table'  => 'members',
		'where'  => 'author = "' . $author . '" && status = 1 '
	]);
	$total_active=$count_merbers->num_rows;

	$range_of_approval = db_select([
		'table'  => 'range_of_approval',
		'where'  => 'range_start <= "' . $total_active . '" && range_end >= "' . $total_active . '"'
	]);
	$range_datas = $range_of_approval->fetch_assoc();
	$email= base64_decode($_GET['t']);
	// $mid = base64_decode($_GET['mid']);
	$mobile = $rs['mobile'];
	
	// For point
	// $irf_point = db_select([
	// 	'table'  => 'range_of_approval_log',
	// 	'where'  => 'author = "' . $author . '"',
	// 	'select' => 'points'
	// ]);	
	// $total=0;
	// while($ipoint=mysqli_fetch_assoc($irf_point)){
	// 	$total+= $ipoint['points'];
	// }
	
	$total_point=$get_previous_totalpoints+$range_datas['points'];
	if($my_token == 0){	
		
		
	$ins = db_insert('range_of_approval_log', [
			"range_of_approval_id" => "'".$range_datas['id']."'",
			"user_email"   => "'".$email."'",
			"mobile" => "'".$mobile."'",
			"count"    => "'".$total_active."'",
			"before_points" => "'".$get_previous_totalpoints."'",
			"points"    => "'".$range_datas['points']."'",
			"pointtillthattime"    => "'".$total_point."'",
			"date" => "'" . date("Y-m-d") . "'",
			"time" => "'" .date("h:i:s") . "'",
			"author" => "'".$author."'",
			"parent_id" => "'".$rs['parent']."'",
			"comment" => "'".$_POST['comment']."'",
			"member_id" => "'".$mid."'",
			"token" => "'".$token."'"
		]);
		db_update('users', ["total_points" => "'{$total_point}'"], $author);
		// echo fh_alerts($lang['alerts']['approval_accept'], "success");
		header("Location: thankyou.php");
	}else{
		echo fh_alerts($lang['alerts']['approval_already_accepted'], "success");
	}
}

// echo fh_alerts($lang['alerts']['emailver'], "success");

 ?>
<div class="container">
	<form action="" method="post" >
		<!-- <input type="hidden" name="email" value="<?php //($_GET['t']); ?>"> -->
		<h2>Approval of your Info</h2>
		<?php if($my_token == 0){?>
		<div class="panel panel-default">
			<div class="panel-body">Hi, <?php echo $rs['firstname'] ?><br> Congratualtion you created as our family<br>Please Click on Accept button with your comment</div>
				
		</div>
		
		<textarea class="form-control" name="comment" id="comment" rows="3"></textarea>
		<button type="submit" class="btn btn-primary">Accept</button>
		<?php }else{?>
			<div class="panel panel-default">
				<div class="panel-body">Hi, <?php echo $rs['firstname'] ?><br> Already accepted Thank You...</div>
					
			</div>
		<?php }?>
  </form>
</div>

</body>
</html>
