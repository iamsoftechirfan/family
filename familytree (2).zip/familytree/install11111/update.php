<?php
# -------------------------------------------------#
#¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤#
#	¤                                            ¤   #
#	¤           Puerto Family Tree 1.5           ¤   #
#	¤--------------------------------------------¤   #
#	¤              By Khalid Puerto              ¤   #
#	¤--------------------------------------------¤   #
#	¤                                            ¤   #
#	¤  Facebook : fb.com/prof.puertokhalid       ¤   #
#	¤  Instagram : instagram.com/khalidpuerto    ¤   #
#	¤  Site : http://www.puertokhalid.com        ¤   #
#	¤  Email: el.bouirtou@gmail.com              ¤   #
#	¤                                            ¤   #
#	¤--------------------------------------------¤   #
#	¤                                            ¤   #
#	¤  Last Update: 13/01/2023                   ¤   #
#	¤                                            ¤   #
#¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤#
# -------------------------------------------------#

error_reporting(E_ALL);
ini_set('display_errors', 'On');
include __DIR__ . '/../configs/connection.php';

?>
<title>Puerto Update</title>
<style>
	body {
		background: #F7F7F7;
		line-height: 24px;
	}

	.install-box {
		width: 600px;
		margin: 40px auto 40px auto;
		background: #FFF;
		font-family: tahoma;
		font-size: 14px;
		box-shadow: 0 1px 5px #EEE;
		border-radius: 10px;
	}

	.install-box h1 {
		padding: 24px 20px;
		margin: 0;
		font-size: 18px;
		border-bottom: 1px solid #EEE;
	}

	.install-box p {
		padding: 20px;
		margin: 0;
	}

	.install-box ul {
		padding: 0 20px;
		font-size: 12px;
	}

	.install-box .button {
		font-size: 16px;
		background: #35c43f;
		color: #FFF;
		text-decoration: none;
		display: block;
		margin-top: 20px;
		text-align: center;
		padding: 16px 0;
		border-radius: 3px;
		width: 100%;
		border: 0;
		font-weight: bold;
	}

	.input {
		padding: 10px 20px 0px 20px;
	}

	.input p {
		padding: 0;
		font-size: 12px;
	}

	label {
		font-weight: bold;
		font-size: 12px;
		margin: 5px;
		display: block;
	}

	input {
		padding: 10px;
		font-size: 12px;
		border: 1px solid #EEE;
		width: 100%;
		border-radius: 5px;
		box-shadow: 0 1px 5px #EEE;
	}

	/* button[type=submit] { padding:10px; font-size:12px; color:#FFF; border:0; background: #DF4444; width:auto;  } */
	li i {
		display: inline-block;
		width: 134px;
	}

	.p-h,
	.p-h a {
		display: inline-block;
		padding: 2px 6px;
		background: #EEE;
		border-radius: 3px;
		-moz-border-radius: 3px;
		-webkit-border-radius: 3px;
		color: #555;
		text-shadow: 0 1px 0 #FFF;
	}

	ul {
		margin: 0 24px
	}

	ul li {
		margin: 6px 0;
	}

	.red {
		color: red;
		background: #ffefef;
		display: block;
		padding: 12px;
		border-radius: 7px;

	}

	.hr {
		display: block;
		border-bottom: 1px solid #EEE;
		margin-bottom: 12px;

	}
</style>


<?php

$step = (isset($_GET['step']) ? (int)($_GET['step']) : '');

if ($step == '') :

?>

	<div class="install-box">
		<form method="post" action="update.php?step=1">

			<h1>Welcome to Puerto Family Tree</h1>
			<p>This action is for updating the script to latest version</p>
			<p>
				<b>Please notice that:</b>
			</p>
			<ul style="margin-bottom: 0; background: #ffd7d7;border-left: 3px solid red;line-height: 20px">
				<li>If you are already have install the v1 of the script make sure to backup your data first.</li>
				<li>You don't need to install the script again if you already did that in v1.</li>
				<li>If you just purchase the script you don't need to update it.</li>
			</ul>
			<p>
				f you have any problem or issue with the script or the instraction that I provide please contact me first ASAP in:
			</p>
			<ul>
				<li><i>my Email</i>: <span class="p-h">el.bouirtou@gmail.com</span></li>
				<li><i>my Facebook account</i>: <span class="p-h"><a href="https://fb.com/prof.puertokhalid">fb.com/prof.puertokhalid</a></span></li>
				<li><i>on the Instagram</i>: <span class="p-h"><a href="https://instagram.com/khalidpuerto">instagram.com/khalidpuerto</a></span></li>
				<li><i>Codecanyon profile</i>: <span class="p-h"><a href="http://codecanyon.net/user/puertokhalid">codecanyon.net/user/puertokhalid</a></span></li>
			</ul>
			<p>
				and I will back to you with all help you need.<br>
				Thanks so much!<br><br />
				<button type="submit" class="button">Update Puerto Script</button>
			</p>
		</form>
	</div>





<?php

else :






	$db->query("DROP TABLE " . prefix . "plans;") or die($db->error);

	$db->query("
CREATE TABLE `" . prefix . "plans` (
  `id` int(11) NOT NULL,
  `plan` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `price_m` float(10,2) UNSIGNED DEFAULT NULL,
  `price_y` float(10,2) DEFAULT NULL,
  `currency` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc1` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc2` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc3` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc4` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc5` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc6` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc7` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc8` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) DEFAULT '0',
  `families_m` int(11) UNSIGNED DEFAULT '0',
  `families_y` int(11) UNSIGNED DEFAULT '0',
  `members_m` int(11) UNSIGNED DEFAULT '0',
  `members_y` int(11) UNSIGNED DEFAULT '0',
  `privates_m` int(11) UNSIGNED DEFAULT '0',
  `privates_y` int(11) UNSIGNED DEFAULT '0',
  `albums` tinyint(1) DEFAULT NULL,
  `pdf` tinyint(1) DEFAULT NULL,
  `heritate` tinyint(1) DEFAULT NULL,
  `show_ads` tinyint(1) DEFAULT '0',
  `support` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
") or die($db->error);

	$db->query("
INSERT INTO `" . prefix . "plans` (`id`, `plan`, `price_m`, `price_y`, `currency`, `desc1`, `desc2`, `desc3`, `desc4`, `desc5`, `desc6`, `desc7`, `desc8`, `created_at`, `families_m`, `families_y`, `members_m`, `members_y`, `privates_m`, `privates_y`, `albums`, `pdf`, `heritate`, `show_ads`, `support`) VALUES
(1, 'Free Plan', 0.00, 0.00, '$', '[n] Famillies', '[n] Members per family', '[n] Private Family', 'Enable to heritate families', 'Enable to create albums', 'PDF Export', 'No advertisements', 'Priority support', 0, 1, 1, 10, 10, 0, 1, 0, 0, 0, 0, 0),
(2, 'Basic Plan', 9.99, 29.99, '$', '[n] Famillies', '[n] Members per family', '[n] Private Family', 'Enable to heritate families', 'Enable to create albums', 'PDF Export', 'No advertisements', 'Priority support', 0, 12, 50, 20, 120, 1, 10, 0, 1, 0, 1, 1),
(3, 'Regular Plan', 19.99, 40.00, '$', 'Unlimited Famillies', 'Unlimited Members per family', 'Unlimited Private Family', 'Enable to heritate families', 'Enable to create albums', 'PDF Export', 'No advertisements', 'Priority support', 0, 999999, 999999, 999999, 999999, 999999, 999999, 1, 1, 1, 1, 1);
") or die($db->error);

	$db->query("
ALTER TABLE `" . prefix . "plans`
  ADD PRIMARY KEY (`id`);
") or die($db->error);

	$db->query("
ALTER TABLE `" . prefix . "plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
") or die($db->error);



	$db->query("ALTER TABLE `" . prefix . "families` ADD `slug` VARCHAR(255) NULL") or die($db->error);
	$db->query("ALTER TABLE `" . prefix . "pages` ADD `slug` VARCHAR(255) NULL") or die($db->error);
	$db->query("ALTER TABLE `" . prefix . "users` ADD `slug` VARCHAR(255) NULL") or die($db->error);
	$db->query("ALTER TABLE `" . prefix . "users` ADD `expired_date` INT UNSIGNED NULL DEFAULT '0'") or die($db->error);
	$db->query("ALTER TABLE `" . prefix . "users` ADD `frequency` INT UNSIGNED NULL DEFAULT '0'") or die($db->error);
	$db->query("ALTER TABLE `" . prefix . "payments` ADD `expired_date` INT UNSIGNED NULL DEFAULT '0'") or die($db->error);
	$db->query("ALTER TABLE `" . prefix . "payments` ADD `frequency` INT UNSIGNED NULL DEFAULT '0'") or die($db->error);





?>


	<div class="install-box">
		<h1>Congratulations...</h1>
		<p>
			Congratulations Puerto Family Tree Script is updated successfully. if you have any problem or issue with the script or the instraction that I provide please contact me first ASAP in:

		</p>
		<ul>
			<li><i>my Email</i>: <span class="p-h">el.bouirtou@gmail.com</span></li>
			<li><i>my Facebook account</i>: <span class="p-h"><a href="https://fb.com/prof.puertokhalid">fb.com/prof.puertokhalid</a></span></li>
			<li><i>on the Instagram</i>: <span class="p-h"><a href="https://instagram.com/khalidpuerto">instagram.com/khalidpuerto</a></span></li>
			<li><i>Codecanyon profile</i>: <span class="p-h"><a href="http://codecanyon.net/user/puertokhalid">codecanyon.net/user/puertokhalid</a></span></li>
		</ul>
		<p>
			and I will back to you with all help you need.<br><br>
			<span class="red">Please do not forget to delete the update file 'update.php'.</span><br>
			<a href="../index.php" class="button">Go to index</a>
		</p>
	</div>

<?php
endif;
