<?php
# -------------------------------------------------#
#¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤#
#	¤                                            ¤   #
#	¤           Puerto Family Tree 1.5           ¤   #
#	¤--------------------------------------------¤   #
#	¤              By Khalid Puerto              ¤   #
#	¤--------------------------------------------¤   #
#	¤                                            ¤   #
#	¤  Facebook : fb.com/prof.puertokhalid       ¤   #
#	¤  Instagram : instagram.com/khalidpuerto    ¤   #
#	¤  Site : http://www.puertokhalid.com        ¤   #
#	¤  Email: el.bouirtou@gmail.com              ¤   #
#	¤                                            ¤   #
#	¤--------------------------------------------¤   #
#	¤                                            ¤   #
#	¤  Last Update: 13/01/2023                   ¤   #
#	¤                                            ¤   #
#¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤#
# -------------------------------------------------#

include __DIR__."/header.php";

$sql = $db->query("SELECT * FROM ".prefix."pages WHERE slug = '{$t}'") or die ($db->error);
if($sql->num_rows):
$rs = $sql->fetch_assoc();
?>
<div class="pt-list">
	<div class="pt-title">
		<span><i class="<?=$rs['icon']?>"></i></span> <b><?=$rs['title']?></b>
	</div>
	<div class="pt-list-item"><?=bbcode($rs['content'])?></div>

</div>
<?php
else:
	echo fh_alerts($lang['alerts']['wrong']);
endif;
$sql->close();
include __DIR__."/footer.php";
?>
