<?php

include __DIR__.'/../../configs/config.php';
header("Content-type: text/css; charset: UTF-8");

?>

.pt-header-menu .pt-logo,
.pt-tree h3 span,
.pt-header-menu .pt-search button,
.pt-pageplans .alert-success {
	background: <?=color1?>;
}
.pt-pageplans .alert-success span {
	color: <?=color1?>;
}
.pt-nav-menu,
.pt-pagination li.pt-active,
.pt-mnewmember button[type=submit],
.pt-pageplans .pt-plans .col:nth-of-type(2) .pt-plan,
.pt-pageplans .pt-plans .pt-plan button {
	background: <?=color2?>;
	border-color: <?=color2?>;
	box-shadow: 4px 1px 6px <?=color2?>45;
}
.pt-nav-menu ul li:first-of-type a:hover,
.pt-nav-menu ul li a:hover {
	background: <?=color4?>;
	color: <?=color1?>;
}
.tree ul li a:not([href]):hover,
.tree ul li a:not([href]):hover .pt-thumb,
.pt-list .pt-title span,
.pt-list-item .pt-thumb {
	box-shadow: 0 0 0 2px <?=color4?>, 0 0 0 4px <?=color2?>;
}
.pt-nav-menu ul li a:hover b,
.pt-index-right button {
	background: <?=color2?>;
	box-shadow: 0px 0px 7px <?=color2?>45;
}
body, .pt-sm {
	background: <?=color4?>;
}
.pt-tree a.exp {
	background: <?=color9?>;
	border: 1px solid <?=color9?>;
}
.pt-tree a.exp .pt-thumb {
	border: 3px solid <?=color9?>;
}
.pt-header-menu .pt-list-menu .pt-notifi a.pt-notyshow {
	color: <?=color2?>;
}
.pt-nav-menu ul li a,
.pt-list-item h3 a,
.pt-index-left h2 {
	color: <?=color3?>;
}
#myTree .pt-item-details .pt-item-body .pt-name {
	color: <?=color5?>;
}
#myTree .pt-item-details.female .pt-name {
	color: <?=color8?>;
}
.choice[type=checkbox]:checked+label:before {
	background-color: <?=color2?>;
	border-color:<?=color2?>;
}
.choice:checked+label:before {
	border-color: <?=color2?>;
	box-shadow: 0 0 0 4px <?=color2?> inset;
}
.tgl-light:checked+.tgl-btn {
	background-color: <?=color2?>;
}
.pt-header-menu .pt-list-menu .pt-new-tree a {
	background: <?=color6?>;
	box-shadow: 0 0 0 0 #FFF, 0 0 0 0 <?=color6?>;
}
.pt-header-menu .pt-list-menu .pt-new-tree a:hover {
	box-shadow: 0 0 0 2px #FFF, 0 0 0 3px <?=color6?>;
}
.pt-header-menu .pt-list-menu .pt-dash a {
	background: <?=color7?>;
	box-shadow: 0 0 0 0 #FFF, 0 0 0 0 <?=color7?>;
}
.pt-header-menu .pt-list-menu .pt-dash a:hover {
	box-shadow: 0 0 0 2px #FFF, 0 0 0 3px <?=color7?>;
}
.pt-form input[type=text], .pt-form input[type=password], .pt-form select,
.amsify-suggestags-area .amsify-suggestags-input-area,
.pt-mnewmember .amsify-suggestags-area .amsify-suggestags-input-area,
.pt-index-right #resetM input {
	background: <?=color4?>;
	border-bottom: 2px solid <?=color2?>;
}
.pt-form .pt-input i, .pt-form .pt-input svg,
.pt-pagination li,
.pt-index-left p,
.pt-index-right .reset a,
.pt-index-right #resetM label i {
	color: <?=color2?>;
}
.bg-0, .pt-flist .more {
	background: <?=color2?>;
	box-shadow: 0px 0px 7px <?=color2?>45;
}
.pt-list-item {
	border: 1px solid <?=color2?>56;
	box-shadow: 0 0 10px <?=color2?>26;
}
.pt-tree h3 {
	background: <?=color10?>;
}
.pt-index-right h3 a.active {
	border-bottom: 2px solid <?=color2?>;
	color: <?=color2?>;
}
